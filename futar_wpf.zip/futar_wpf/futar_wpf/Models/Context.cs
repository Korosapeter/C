﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql;

namespace futar_wpf.Models
{
    public class Context : DbContext
    {
        public DbSet<Megrendeles> Megrendelesek { get; set; }
        public DbSet<Etel> Etel { get; set; }
        public DbSet<Futar> Futar { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            //ConnectionString
            string c = "server = localhost; userid = root; password =; database = futar_wpf";

            //OptionBulider: ConnectionString + Szerver verzió (manuálisan, vagy Autodetect)
            optionsBuilder.UseMySql(c, ServerVersion.AutoDetect(c));

        }
    }
}
