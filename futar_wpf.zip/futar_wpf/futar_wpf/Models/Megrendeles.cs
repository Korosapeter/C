﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futar_wpf.Models
{
    public class Megrendeles
    {
        public int Id { get; set; }
        public Futar FutarId { get; set; }
        public Etel EtelId { get; set; }
        public string Cím { get; set; }
        public string FizetesiMod { get; set; }
        public DateTime Datum { get; set; }
    }
}
