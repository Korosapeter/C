﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futar_wpf.Models
{
    public class Futar
    {
        public int Id { get; set; } 
        public string Nev { get; set; }
        public string Jarmutipus { get; set; }

        public Futar() { }
    }
}
