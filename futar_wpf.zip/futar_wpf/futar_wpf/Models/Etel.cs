﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace futar_wpf.Models
{
    public class Etel
    {
        public int Id { get; set; }
        public string Nev { get; set; }
        public string Kategoria { get; set;}
        public int Ar { get; set; }

        public Etel() 
        {
        
        }
    }
}
