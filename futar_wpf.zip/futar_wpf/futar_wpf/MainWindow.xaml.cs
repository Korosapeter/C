﻿using futar_wpf.Ablakok;
using futar_wpf.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace futar_wpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static Context c;
        Megrendeles_leadas ujrendeles;
        Ujetel ujetel;
        UjFutar ujFutar;
        Etel_lista etel_lista;
        Futar_lista futar_Lista;

        public MainWindow()
        {
            InitializeComponent();
            c = new Context();
            c.Database.EnsureCreated();
            ujrendeles = new Megrendeles_leadas(c);
            ujetel =new Ujetel(c);
            ujFutar = new UjFutar(c);
            etel_lista = new Etel_lista(c);
            futar_Lista = new Futar_lista(c);
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            contentcontrol.Content = ujetel.Content;
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            contentcontrol.Content = ujFutar.Content;
        }

        private void buttonRendeles_Click(object sender, RoutedEventArgs e)
        {
            contentcontrol.Content = ujrendeles.Content;
        }

        private void buttonetellista_Click(object sender, RoutedEventArgs e)
        {
            contentcontrol.Content = etel_lista.Content;
        }

        private void buttonfutarlista_Click(object sender, RoutedEventArgs e)
        {
            contentcontrol.Content = futar_Lista.Content;
        }
    }
}
